
document.write("Welcome To Mphasis 215 Angular Batch");
alert("Welcome To Mphasis 215 Angular Batch")